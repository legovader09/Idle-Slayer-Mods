﻿namespace $safeprojectname$;

public static class MyPluginInfo
{
    public const string PLUGIN_GUID = "$safeprojectname$";
    public const string PLUGIN_NAME = "$projectname$";
    public const string PLUGIN_VERSION = "1.0.0";
    public const string PLUGIN_AUTHOR = "$author$";
}